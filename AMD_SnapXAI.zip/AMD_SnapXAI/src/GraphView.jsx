import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  BackgroundVariant,
} from 'reactflow';
import 'reactflow/dist/style.css';
import TopicNode from './TopicNode';
import { Search, RefreshCw, Maximize2 } from 'lucide-react';

const nodeTypes = { topicNode: TopicNode };

export default function GraphView({ nodes: initialNodes, edges: initialEdges, onNodeClick, selectedNodeId, topic, onReset }) {
  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, , onEdgesChange] = useEdgesState(initialEdges);

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      {/* Controls bar */}
      <div className="graph-controls" id="graph-controls-bar">
        <p className="topic-label">
          Exploring: <span>"{topic}"</span>
        </p>
        <div className="control-divider" />
        <button className="control-btn" onClick={onReset} id="new-search-btn">
          <Search size={13} />
          New Search
        </button>
      </div>

      {/* Hint */}
      <div className="empty-hint">
        <span>💡</span>
        Click any node to explore that concept in detail
      </div>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={(_, node) => onNodeClick(node)}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.3 }}
        minZoom={0.3}
        maxZoom={2}
        attributionPosition="bottom-right"
      >
        <Background
          variant={BackgroundVariant.Dots}
          gap={28}
          size={1}
          color="rgba(255,255,255,0.05)"
        />
        <Controls position="bottom-left" />
        <MiniMap
          nodeColor={(node) => node.data?.isRoot ? '#7c3aed' : '#1e1e3f'}
          maskColor="rgba(5, 5, 16, 0.7)"
          position="bottom-right"
          style={{ marginBottom: 40 }}
        />
      </ReactFlow>
    </div>
  );
}
