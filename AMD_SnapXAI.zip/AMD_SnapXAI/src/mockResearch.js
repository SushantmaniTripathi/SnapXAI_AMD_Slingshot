/**
 * mockResearch.js
 * Simulates a RAG-based research pipeline.
 * Returns a structured graph of nodes and edges for any given topic.
 * In production, replace `generateResearch` with real API calls to Gemini.
 */

const TOPIC_DATABASE = {
  rag: {
    rootLabel: "RAG (Retrieval-Augmented Generation)",
    rootSummary: "RAG is a technique that gives AI an open-book advantage — it searches for real information before answering, making responses far more accurate and up-to-date.",
    rootKeyPoints: [
      "📚 RAG = Search first, then answer",
      "🧠 Combines the power of a search engine + AI language model",
      "🔄 Retrieves real documents, then generates answers from them",
      "✅ More accurate than plain AI which can 'hallucinate' facts",
      "🚀 Powers modern apps like ChatGPT with browsing, Perplexity.ai",
    ],
    children: [
      {
        id: "retrieval",
        label: "Retrieval",
        emoji: "🔍",
        summary: "The system searches a database or the internet to find documents or facts most relevant to your question.",
        keyPoints: [
          "🔍 Works like a smart Google search tailored to your question",
          "📄 Scans thousands of documents in milliseconds",
          "🎯 Uses vector embeddings to find semantically similar content",
          "🏆 Only the top K most relevant chunks are selected",
          "💡 Quality of retrieval directly determines quality of the answer",
        ],
        children: [
          {
            id: "vector-db",
            label: "Vector Database",
            emoji: "🗃️",
            summary: "A special database that stores meaning, not just words — so searching for 'fast car' also finds results about 'quick automobile'.",
            keyPoints: [
              "🔢 Stores data as lists of numbers called 'vectors'",
              "🧲 Similar meanings produce similar vectors (close in space)",
              "⚡ Can search millions of records in milliseconds",
              "🏛️ Examples: Pinecone, Weaviate, ChromaDB",
              "🆓 ChromaDB is free and runs on your own computer",
            ],
          },
          {
            id: "embeddings",
            label: "Embeddings",
            emoji: "🔗",
            summary: "Embeddings convert text into a list of numbers that capture its meaning — allowing computers to measure how 'similar' two pieces of text are.",
            keyPoints: [
              "📐 Text is converted into arrays of 768–3072 numbers",
              "🤝 'King' and 'Queen' will have very similar number arrays",
              "🌐 Created by encoder models like BERT, Sentence-BERT",
              "💡 This is why searching 'happy' can return results about 'joyful'",
              "🆓 Free models available via HuggingFace",
            ],
          },
        ],
      },
      {
        id: "augmentation",
        label: "Augmentation",
        emoji: "➕",
        summary: "Retrieved documents are combined with the original question and fed into the AI together — giving the AI all the context it needs to answer perfectly.",
        keyPoints: [
          "📋 Combines your question + retrieved documents into one big prompt",
          "🧩 Like handing the AI a cheat sheet before an exam",
          "📏 Context window size limits how much you can include",
          "🏅 Best chunks are ranked and only top ones are used",
          "✂️ Long documents are split into smaller chunks first",
        ],
        children: [],
      },
      {
        id: "generation",
        label: "Generation",
        emoji: "✨",
        summary: "The AI reads the retrieved context and crafts a clear, accurate, and well-structured answer specifically tailored to your question.",
        keyPoints: [
          "🤖 The LLM (Large Language Model) does the final writing",
          "📖 It reads the provided context, not its training memory",
          "🎨 Can format output as bullet points, paragraphs, or code",
          "🔑 The answer is grounded in real retrieved facts",
          "⚠️ Without RAG, the AI might make up (hallucinate) facts",
        ],
        children: [],
      },
    ],
  },
  cloud: {
    rootLabel: "Cloud Computing",
    rootSummary: "Cloud computing is renting computing power, storage, and software over the internet instead of owning it — like electricity from a power grid instead of your own generator.",
    rootKeyPoints: [
      "☁️ Use computers over the internet instead of owning them",
      "💰 Pay only for what you use (like a utility bill)",
      "🌍 Access your data from anywhere in the world",
      "📈 Scale up or down instantly based on your needs",
      "🔒 Professional security managed by cloud providers",
    ],
    children: [
      {
        id: "storage",
        label: "Storage",
        emoji: "💾",
        summary: "Cloud storage lets you save files online so you can access them from any device, anywhere — without worrying about hard drive failures.",
        keyPoints: [
          "📁 Save files online — no physical hard drive needed",
          "📱 Access from phone, laptop, tablet — any device",
          "🔄 Files are automatically backed up to prevent loss",
          "🤝 Share files with others with just a link",
          "🆓 Examples: Google Drive (15GB free), OneDrive (5GB free)",
        ],
        children: [],
      },
      {
        id: "compute",
        label: "Compute Power",
        emoji: "⚡",
        summary: "Rent powerful servers on demand to run heavy tasks like training AI models or handling millions of website visitors — without buying expensive hardware.",
        keyPoints: [
          "🖥️ Rent powerful servers without buying them",
          "⚡ Run heavy AI training or big data processing jobs",
          "📊 Scale from 1 user to 1 million users automatically",
          "💡 Examples: AWS EC2, Google Compute Engine, Azure VMs",
          "💰 Only pay per hour of usage — stop when done",
        ],
        children: [],
      },
      {
        id: "saas",
        label: "Software as a Service",
        emoji: "🛠️",
        summary: "Use software directly in your browser without downloading or installing anything — the provider handles all updates and maintenance for you.",
        keyPoints: [
          "🌐 Use apps directly in your browser — no download needed",
          "🔄 Automatic updates — always on the latest version",
          "💻 Examples: Gmail, Slack, Zoom, Figma, Canva",
          "🏢 Businesses pay per user per month subscription",
          "📱 Works on any device — phone, tablet, or computer",
        ],
        children: [],
      },
    ],
  },
  ai: {
    rootLabel: "Artificial Intelligence (AI)",
    rootSummary: "AI is the science of making computers smart enough to learn, reason, and solve problems — tasks that once required human intelligence.",
    rootKeyPoints: [
      "🧠 Teaching computers to think and learn like humans",
      "📊 AI learns from massive amounts of example data",
      "🚀 Powers voice assistants, self-driving cars, medical diagnosis",
      "🔄 Gets smarter over time as it sees more data",
      "⚠️ Still has limitations — can be wrong and biased",
    ],
    children: [
      {
        id: "ml",
        label: "Machine Learning",
        emoji: "📊",
        summary: "Machine Learning teaches computers to learn patterns from data without being explicitly programmed for every rule — it figures out the rules itself.",
        keyPoints: [
          "📚 Learns rules from examples instead of being programmed",
          "🎯 Show it 1000 cat photos → it learns what a cat looks like",
          "📈 The more data, the smarter the model becomes",
          "🔄 Three types: Supervised, Unsupervised, Reinforcement",
          "💡 Used in spam filters, recommendations, fraud detection",
        ],
        children: [
          {
            id: "deep-learning",
            label: "Deep Learning",
            emoji: "🕸️",
            summary: "Deep Learning uses artificial neural networks inspired by the human brain to recognize patterns in images, audio, and text with superhuman accuracy.",
            keyPoints: [
              "🧠 Modelled after how neurons connect in the human brain",
              "🖼️ Excels at image, video, speech, and text understanding",
              "🏆 Achieves superhuman accuracy on many benchmarks",
              "⚡ Requires powerful GPUs to train",
              "🤖 Powers ChatGPT, DALL-E, voice assistants",
            ],
          },
        ],
      },
      {
        id: "nlp",
        label: "Natural Language Processing",
        emoji: "💬",
        summary: "NLP teaches computers to read, understand, and write human language — enabling chatbots, translation, and sentiment analysis.",
        keyPoints: [
          "💬 Computers understanding human language (text + speech)",
          "🌍 Powers real-time translation (Google Translate)",
          "😊 Sentiment analysis — understanding if text is positive/negative",
          "🤖 Foundation of chatbots and virtual assistants",
          "📄 Also used for document summarization and search",
        ],
        children: [],
      },
      {
        id: "computer-vision",
        label: "Computer Vision",
        emoji: "👁️",
        summary: "Computer Vision gives machines the ability to 'see' and understand images and videos — used in self-driving cars, medical imaging, and facial recognition.",
        keyPoints: [
          "👁️ Teaches computers to see and interpret visual data",
          "🚗 Used in self-driving cars to detect objects & pedestrians",
          "🏥 Detects cancer in medical scans more accurately than doctors",
          "📸 Powers facial recognition in phones & security systems",
          "🏭 Used in factories to detect defective products",
        ],
        children: [],
      },
    ],
  },
};

// Auto-layout calculator for nodes
function calculateLayout(children, startX, startY, levelGap = 220, nodeGap = 180) {
  const positions = [];
  const totalWidth = (children.length - 1) * nodeGap;
  const startXOffset = startX - totalWidth / 2;

  children.forEach((child, i) => {
    const x = startXOffset + i * nodeGap;
    const y = startY + levelGap;
    positions.push({ id: child.id, x, y });

    if (child.children && child.children.length > 0) {
      const subPositions = calculateLayout(child.children, x, y, levelGap, nodeGap * 0.8);
      positions.push(...subPositions);
    }
  });

  return positions;
}

// Flatten nested topic data into nodes and edges for ReactFlow
function flattenTopic(topic) {
  const nodes = [];
  const edges = [];

  // Root node
  nodes.push({
    id: "root",
    type: "topicNode",
    position: { x: 400, y: 50 },
    data: {
      label: topic.rootLabel,
      emoji: "🌐",
      summary: topic.rootSummary,
      keyPoints: topic.rootKeyPoints,
      isRoot: true,
    },
  });

  // Recursive flatten
  function processChildren(children, parentId, depth = 1) {
    const positions = calculateLayout(children, 400, 50 + depth * 220, 220, 220);

    children.forEach((child) => {
      const pos = positions.find((p) => p.id === child.id) || { x: 300, y: 200 };

      nodes.push({
        id: child.id,
        type: "topicNode",
        position: { x: pos.x, y: pos.y },
        data: {
          label: child.label,
          emoji: child.emoji || "📌",
          summary: child.summary,
          keyPoints: child.keyPoints,
          isRoot: false,
        },
      });

      edges.push({
        id: `${parentId}-${child.id}`,
        source: parentId,
        target: child.id,
        type: "smoothstep",
        animated: true,
        style: { stroke: "#7c3aed", strokeWidth: 2 },
      });

      if (child.children && child.children.length > 0) {
        processChildren(child.children, child.id, depth + 1);
      }
    });
  }

  processChildren(topic.children, "root");

  return { nodes, edges };
}

// Helper to match topics
function findBestMatch(query) {
  const lower = query.toLowerCase();
  const keys = Object.keys(TOPIC_DATABASE);

  // Exact match
  for (const key of keys) {
    if (lower.includes(key)) return TOPIC_DATABASE[key];
  }

  // Alias matches
  if (lower.includes("retrieval") || lower.includes("retrieval augmented")) return TOPIC_DATABASE.rag;
  if (lower.includes("cloud") || lower.includes("aws") || lower.includes("azure")) return TOPIC_DATABASE.cloud;
  if (lower.includes("artificial") || lower.includes("machine learning") || lower.includes("deep learning") || lower.includes("neural")) return TOPIC_DATABASE.ai;

  return null;
}

// Generic fallback generator for unknown topics
function generateGenericTopic(query) {
  const capitalized = query.trim().replace(/\b\w/g, (c) => c.toUpperCase());
  return {
    rootLabel: capitalized,
    rootSummary: `${capitalized} is a fascinating subject that can be understood through its core building blocks. Click each concept below to explore it in detail.`,
    rootKeyPoints: [
      `🌟 ${capitalized} is built on a few core foundational concepts`,
      "📖 Understanding each component leads to mastery of the whole",
      "🔗 Concepts are deeply interconnected and support each other",
      "💡 Start with the basics before diving into advanced topics",
      "🚀 Real-world applications make abstract concepts concrete",
    ],
    children: [
      {
        id: "concept-1",
        label: "Core Concepts",
        emoji: "🧩",
        summary: `The fundamental ideas that form the building blocks of ${capitalized}. Mastering these gives you a strong base to understand everything else.`,
        keyPoints: [
          "🧩 Every complex system is built from simple building blocks",
          "📐 Core concepts define the rules and boundaries of the field",
          "🔑 These are the 'vocabulary' of the subject",
          "📚 Usually taught first in any formal education on this topic",
          "💡 Understanding these unlocks all advanced topics",
        ],
        children: [],
      },
      {
        id: "concept-2",
        label: "How It Works",
        emoji: "⚙️",
        summary: `A step-by-step look at the mechanisms and processes that power ${capitalized} — from input to output.`,
        keyPoints: [
          "⚙️ Understanding the 'engine' behind the subject",
          "🔄 Most systems follow an input → process → output pattern",
          "📊 Data flows and transforms through each step",
          "🧪 Experiments help verify how the mechanism truly works",
          "🔍 Edge cases reveal the real boundaries of the system",
        ],
        children: [],
      },
      {
        id: "concept-3",
        label: "Real-World Uses",
        emoji: "🌍",
        summary: `Practical applications of ${capitalized} that you encounter in everyday life — making abstract ideas tangible and motivating.`,
        keyPoints: [
          "🌍 Theory becomes powerful when applied to real problems",
          "📱 Most modern apps and services use these principles",
          "💼 High demand in industry means strong career opportunities",
          "🏆 Best learners study real case studies, not just textbooks",
          "🔬 Research constantly uncovers new applications",
        ],
        children: [],
      },
      {
        id: "concept-4",
        label: "Key Challenges",
        emoji: "⚠️",
        summary: `The main problems and limitations in ${capitalized} that researchers and practitioners are actively working to solve.`,
        keyPoints: [
          "⚠️ No technology is perfect — knowing limitations is crucial",
          "🔧 Challenges drive innovation and new research directions",
          "🤔 Ethical considerations are increasingly important",
          "📏 Scalability is often the hardest engineering challenge",
          "🌱 Open problems are great opportunities for new contributors",
        ],
        children: [],
      },
    ],
  };
}

/**
 * Main export: simulate async research call
 * Replace this function body with a real Gemini API call for live research
 */
export async function generateResearch(query) {
  // Simulate network/AI delay
  await new Promise((resolve) => setTimeout(resolve, 1800));

  const topic = findBestMatch(query) || generateGenericTopic(query);
  return flattenTopic(topic);
}
