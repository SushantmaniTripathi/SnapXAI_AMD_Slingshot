import { memo } from 'react';
import { Handle, Position } from 'reactflow';

const TopicNode = memo(({ data, selected }) => {
  return (
    <div className={`topic-node ${data.isRoot ? 'root-node' : ''} ${selected ? 'selected' : ''}`}>
      <Handle type="target" position={Position.Top} style={{ background: 'transparent', border: 'none' }} />
      <span className="node-emoji">{data.emoji}</span>
      <div className="node-label">{data.label}</div>
      <div className="node-hint">Click to explore →</div>
      <Handle type="source" position={Position.Bottom} style={{ background: 'transparent', border: 'none' }} />
    </div>
  );
});

TopicNode.displayName = 'TopicNode';
export default TopicNode;
