import { useState, useRef, useCallback } from 'react';
import { Search, Sparkles, Brain, Zap, Globe } from 'lucide-react';
import GraphView from './GraphView';
import DetailsPanel from './DetailsPanel';
import { generateResearch } from './mockResearch';

const LOADING_STEPS = [
  { id: 1, text: 'Parsing your topic...' },
  { id: 2, text: 'Searching knowledge base...' },
  { id: 3, text: 'Extracting key concepts...' },
  { id: 4, text: 'Building concept graph...' },
  { id: 5, text: 'Rendering visual map...' },
];

const SUGGESTED_TOPICS = [
  { label: '🤖 RAG', query: 'RAG' },
  { label: '☁️ Cloud Computing', query: 'cloud computing' },
  { label: '🧠 Artificial Intelligence', query: 'artificial intelligence' },
  { label: '🔒 Cryptography', query: 'cryptography' },
  { label: '📡 Internet', query: 'how does the internet work' },
];

export default function App() {
  const [query, setQuery] = useState('');
  const [graphData, setGraphData] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [searchedTopic, setSearchedTopic] = useState('');
  const inputRef = useRef(null);

  const runSteps = useCallback(async () => {
    for (let i = 0; i < LOADING_STEPS.length; i++) {
      setActiveStep(i);
      await new Promise((r) => setTimeout(r, 280));
    }
  }, []);

  const handleSearch = useCallback(async (searchQuery) => {
    const q = searchQuery || query;
    if (!q.trim()) return;

    setIsLoading(true);
    setSelectedNode(null);
    setGraphData(null);
    setSearchedTopic(q.trim());

    // Run loading animation steps in parallel with actual research
    runSteps();

    try {
      const data = await generateResearch(q.trim());
      setGraphData(data);
    } catch (err) {
      console.error('Research failed:', err);
    } finally {
      setIsLoading(false);
      setActiveStep(0);
    }
  }, [query, runSteps]);

  const handleReset = useCallback(() => {
    setGraphData(null);
    setSelectedNode(null);
    setQuery('');
    setSearchedTopic('');
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSearch();
  };

  const isGraphVisible = !isLoading && graphData !== null;
  const isHeroVisible = !isLoading && graphData === null;

  return (
    <>
      {/* Animated Background */}
      <div className="bg-animated">
        <div className="bg-orb bg-orb-1" />
        <div className="bg-orb bg-orb-2" />
        <div className="bg-orb bg-orb-3" />
      </div>

      <div className="app">
        {/* Header */}
        <header className="header">
          <div className="header-brand">
            <div className="header-logo">🔬</div>
            <h1 className="header-title">ResearchAI</h1>
          </div>
          <span className="header-badge">
            <Sparkles size={9} style={{ display: 'inline', marginRight: 4 }} />
            Visual Agent
          </span>
        </header>

        {/* Main */}
        <main className="main">
          {/* Hero / Search Screen */}
          <div className={`hero ${!isHeroVisible ? 'hidden' : ''}`}>
            <div className="hero-text">
              <h2 className="hero-headline">
                Understand <span className="gradient-text">anything</span>
                <br />visually.
              </h2>
              <p className="hero-sub">
                Type any topic and watch it transform into an interactive knowledge graph you can explore and click.
              </p>
            </div>

            <div className="search-container">
              <div className="search-wrapper">
                <Search className="search-icon" size={20} />
                <input
                  ref={inputRef}
                  id="main-search-input"
                  className="search-input"
                  type="text"
                  placeholder="e.g. How does RAG work? What is Machine Learning?"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  autoFocus
                  aria-label="Research topic input"
                />
                <button
                  id="research-btn"
                  className="search-btn"
                  onClick={() => handleSearch()}
                  disabled={!query.trim() || isLoading}
                >
                  <Zap size={14} />
                  Research
                </button>
              </div>

              {/* Suggested Topics */}
              <div className="search-tags" role="list" aria-label="Suggested topics">
                {SUGGESTED_TOPICS.map((t) => (
                  <button
                    key={t.query}
                    className="search-tag"
                    role="listitem"
                    id={`tag-${t.query.replace(/\s+/g, '-')}`}
                    onClick={() => {
                      setQuery(t.query);
                      handleSearch(t.query);
                    }}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature highlights */}
            <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap', justifyContent: 'center' }}>
              {[
                { icon: <Globe size={16} />, text: 'Deep Research' },
                { icon: <Brain size={16} />, text: 'Concept Mapping' },
                { icon: <Sparkles size={16} />, text: 'Click to Explore' },
              ].map(({ icon, text }) => (
                <div key={text} style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-muted)', fontSize: 13 }}>
                  <span style={{ color: 'var(--accent-primary)' }}>{icon}</span>
                  {text}
                </div>
              ))}
            </div>
          </div>

          {/* Loading Overlay */}
          {isLoading && (
            <div className="loading-overlay" id="loading-overlay" aria-live="polite">
              <div className="loading-spinner" />
              <div className="loading-text">Researching "{searchedTopic}"...</div>
              <div className="loading-steps">
                {LOADING_STEPS.map((step, i) => (
                  <div key={step.id} className={`loading-step ${i <= activeStep ? 'active' : ''}`}>
                    <div className="loading-step-dot" />
                    {step.text}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Graph + Panel */}
          {isGraphVisible && (
            <>
              <div className="graph-area" id="graph-canvas">
                <GraphView
                  nodes={graphData.nodes}
                  edges={graphData.edges}
                  onNodeClick={setSelectedNode}
                  selectedNodeId={selectedNode?.id}
                  topic={searchedTopic}
                  onReset={handleReset}
                />
              </div>
              <DetailsPanel node={selectedNode} onClose={() => setSelectedNode(null)} />
            </>
          )}
        </main>
      </div>
    </>
  );
}
