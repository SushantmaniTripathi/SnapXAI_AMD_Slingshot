import { X, Lightbulb, FileText, Brain } from 'lucide-react';

const memoryTips = {
  default: "Think of this concept like a puzzle piece — it only makes complete sense when you see how it fits with the others around it.",
  storage: "Memory trick: Think of cloud storage like a locker at a gym — it's not your locker, but you own your key.",
  retrieval: "Memory trick: Think of retrieval like a librarian who instantly knows exactly which shelf has the book you need.",
  compute: "Memory trick: Compute power is renting a race car for a day instead of buying one — you get the speed without the cost.",
};

function getMemoryTip(nodeId) {
  return memoryTips[nodeId] || memoryTips.default;
}

export default function DetailsPanel({ node, onClose }) {
  if (!node) return null;

  const { label, emoji, summary, keyPoints } = node.data;
  const memoryTip = getMemoryTip(node.id);

  return (
    <aside className={`details-panel ${node ? 'open' : ''}`} aria-label="Topic details">
      <div className="panel-glow" />

      {/* Header */}
      <div className="panel-header">
        <button className="panel-close" onClick={onClose} aria-label="Close panel" id="panel-close-btn">
          <X size={16} />
        </button>
        <span className="panel-emoji">{emoji}</span>
        <h2 className="panel-title">{label}</h2>
        <span className="panel-tag">
          <span style={{ marginRight: 4 }}>📌</span>
          Concept
        </span>
      </div>

      {/* Body */}
      <div className="panel-body">
        {/* Simple Summary */}
        <div className="summary-section">
          <div className="section-label">
            <FileText size={10} style={{ display: 'inline', marginRight: 6 }} />
            Simple Summary
          </div>
          <p className="summary-text">{summary}</p>
        </div>

        {/* Key Points */}
        <div className="keypoints-section">
          <div className="section-label">
            <Lightbulb size={10} style={{ display: 'inline', marginRight: 6 }} />
            Key Points to Remember
          </div>
          {keyPoints && keyPoints.map((point, i) => (
            <div className="key-point" key={i} id={`key-point-${i}`}>
              <div className="key-point-num">{i + 1}</div>
              <p className="key-point-text">{point}</p>
            </div>
          ))}
        </div>

        {/* Memory Tip */}
        <div className="memory-tip">
          <div className="section-label">
            <Brain size={10} style={{ display: 'inline', marginRight: 6 }} />
            Memory Tip
          </div>
          <p className="memory-text">{memoryTip}</p>
        </div>
      </div>
    </aside>
  );
}
